﻿const $btnPrint = document.querySelector("#btnPrint");
$btnPrint.addEventListener("click", () => {
    alert('amang');
    //window.print();
});